package com.example.toats;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText id, password;
    private Button loginb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        id = findViewById(R.id.id);
        password = findViewById(R.id.password);
        loginb = findViewById(R.id.loginbutton);

        loginb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginverification();
            }
        });
    }

    public void loginverification() {
        String iddata = id.getText().toString();
        String passdata = password.getText().toString();

        if (iddata.isEmpty() || passdata.isEmpty()) {
            Toast.makeText(this, "Enter login data", Toast.LENGTH_SHORT).show();
        } else {
            if (iddata.equals("Student@gmail.com")) {
                if (passdata.equals("12345")) {
                    Toast.makeText(this, "Login Successful", Toast.LENGTH_LONG).show();

                    Intent intent = new Intent(MainActivity.this, login.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(this, "Incorrect Password", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Incorrect email id", Toast.LENGTH_LONG).show();
            }
        }
    }
}
