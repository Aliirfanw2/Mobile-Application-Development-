package com.example.flutter_firbase_assign5

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
